from PyQt6.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

from ui.theme import DIALOG_STYLES


class SupportDialog(QDialog):
    """Role-specific support popup with an optional screen refresh action."""

    def __init__(self, context_text, refresh_callback, parent=None, show_refresh=True):
        super().__init__(parent)
        self.refresh_callback = refresh_callback
        self.setWindowTitle("Library Support")
        self.setFixedWidth(470)
        self.setStyleSheet(DIALOG_STYLES)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 24, 24, 22)
        lay.setSpacing(14)

        title = QLabel("Library Support")
        title.setObjectName("title")
        text = QLabel(context_text)
        text.setWordWrap(True)
        text.setMinimumWidth(400)

        self.feedback = QLabel("")
        self.feedback.setObjectName("ok")
        self.feedback.setWordWrap(True)

        lay.addWidget(title)
        lay.addWidget(text)
        lay.addWidget(self.feedback)

        row = QHBoxLayout()
        row.addStretch()

        if show_refresh:
            refresh = QPushButton("↻  Refresh Screen")
            refresh.clicked.connect(self._refresh)
            row.addWidget(refresh)

        close = QPushButton("Close")
        close.setObjectName("secondary")
        close.clicked.connect(self.accept)
        row.addWidget(close)
        lay.addLayout(row)

    def _refresh(self):
        refreshed = self.refresh_callback() if self.refresh_callback else False
        if refreshed is False:
            self.feedback.setText("The screen is already up to date.")
        else:
            self.feedback.setText("Screen refreshed successfully.")
