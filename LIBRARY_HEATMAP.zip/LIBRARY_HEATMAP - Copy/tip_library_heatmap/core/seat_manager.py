import sqlite3
import sys
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from student_login_logger import normalize_student_id, record_student_login  # noqa: E402

DB_PATH = ROOT / "library_shared_data.sqlite3"
MAX_RESERVATIONS_PER_DAY = 5
VALID_STATUSES = ("available", "occupied", "reserved")

FLOOR_NAMES = {
    "first": "First Floor",
    "right": "Second Floor (Right Wing)",
    "left": "Second Floor (Left Wing)",
}

ACTION_LABELS = {
    "occupied": "Checked in",
    "released": "Checked out",
    "reservation_created": "Reservation created",
    "reservation_cancelled": "Reservation cancelled",
    "reservation_checked_in": "Reservation checked in",
    "librarian_status_override": "Librarian status update",
    "login_log_failed": "Login log write failed",
}

# Order the floors are paged through in the staff log windows.
FLOOR_ORDER = tuple(FLOOR_NAMES)


def seat_floor(seat_id):
    return FLOOR_NAMES.get(seat_id.partition("-")[0], "Unknown floor")


def seat_label(seat_id):
    return f"{seat_floor(seat_id)} · Seat {seat_id.partition('-')[2]}"


def _now_iso():
    """Naive local timestamp. Matches how reservation start/end are stored."""
    return datetime.now().replace(microsecond=0).isoformat()


class SeatManager:
    """All seat state lives in one SQLite file shared by every running window.

    Every call opens a short-lived connection, so the student heat map and the
    staff heat map (separate processes) always read what the other one wrote.
    """

    def __init__(self):
        self._init_db()

    # ------------------------------------------------------------------ plumbing
    @contextmanager
    def _db(self, write=False):
        conn = sqlite3.connect(DB_PATH, timeout=10)
        conn.row_factory = sqlite3.Row
        try:
            if write:
                # Take the write lock up front so two windows can't both pass a
                # "is this seat free?" check and then both claim it.
                conn.execute("BEGIN IMMEDIATE")
            with conn:
                yield conn
        finally:
            conn.close()

    def _init_db(self):
        with self._db(write=True) as db:
            db.execute("""CREATE TABLE IF NOT EXISTS seats (
                seat_id TEXT PRIMARY KEY,
                status TEXT NOT NULL DEFAULT 'available',
                student_id TEXT NOT NULL DEFAULT '',
                updated_at TEXT NOT NULL
            )""")
            db.execute("""CREATE TABLE IF NOT EXISTS reservations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                seat_id TEXT NOT NULL,
                student_id TEXT NOT NULL,
                date TEXT NOT NULL,
                start TEXT NOT NULL,
                end TEXT NOT NULL,
                created_at TEXT NOT NULL
            )""")
            db.execute("""CREATE TABLE IF NOT EXISTS reservation_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                seat_id TEXT NOT NULL,
                action TEXT NOT NULL,
                student_id TEXT NOT NULL DEFAULT '',
                details TEXT NOT NULL DEFAULT ''
            )""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_res_seat ON reservations(seat_id)")
            db.execute("CREATE INDEX IF NOT EXISTS idx_res_date ON reservations(date)")

    def _state(self, db, seat_id, now_iso):
        """(status, student_id) for one seat. A reservation only counts until it ends."""
        row = db.execute(
            "SELECT status, student_id FROM seats WHERE seat_id=?", (seat_id,)
        ).fetchone()
        if row and row["status"] in ("occupied", "reserved"):
            return row["status"], row["student_id"]
        res = db.execute(
            'SELECT student_id FROM reservations WHERE seat_id=? AND "end" > ? ORDER BY start LIMIT 1',
            (seat_id, now_iso),
        ).fetchone()
        if res:
            return "reserved", res["student_id"]
        return "available", ""

    def _log(self, db, seat_id, action, student_id="", details=""):
        db.execute(
            "INSERT INTO reservation_logs(timestamp,seat_id,action,student_id,details) VALUES(?,?,?,?,?)",
            (datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z"), seat_id, action, student_id, details),
        )

    def log_reservation_event(self, seat_id, action, student_id="", details=""):
        with self._db(write=True) as db:
            self._log(db, seat_id, action, student_id, details)

    # ------------------------------------------------------------------ reads
    def status(self, seat_id):
        with self._db() as db:
            return self._state(db, seat_id, _now_iso())[0]

    def all_statuses(self):
        """{seat_id: status} for every non-available seat, in two queries.
        Seats missing from the dict are available."""
        now = _now_iso()
        statuses = {}
        with self._db() as db:
            for row in db.execute("SELECT seat_id, status FROM seats WHERE status IN ('occupied','reserved')"):
                statuses[row["seat_id"]] = row["status"]
            for row in db.execute('SELECT DISTINCT seat_id FROM reservations WHERE "end" > ?', (now,)):
                statuses.setdefault(row["seat_id"], "reserved")
        return statuses

    def seat_info(self, seat_id):
        """(status, student_id) -- used by the librarian's status editor."""
        with self._db() as db:
            return self._state(db, seat_id, _now_iso())

    def owner(self, seat_id):
        with self._db() as db:
            row = db.execute(
                "SELECT student_id FROM seats WHERE seat_id=? AND status='occupied'", (seat_id,)
            ).fetchone()
        return row["student_id"] if row else None

    def get_date_reservation_count(self, date_str):
        with self._db() as db:
            return db.execute("SELECT COUNT(*) FROM reservations WHERE date=?", (date_str,)).fetchone()[0]

    def is_date_overbooked(self, date_str):
        return self.get_date_reservation_count(date_str) >= MAX_RESERVATIONS_PER_DAY

    def check_time_overlap(self, seat_id, date_str, new_start, new_end):
        with self._db() as db:
            rows = db.execute(
                'SELECT start, "end" FROM reservations WHERE seat_id=? AND date=?', (seat_id, date_str)
            ).fetchall()
        return any(max(datetime.fromisoformat(r["start"]), new_start) <
                   min(datetime.fromisoformat(r["end"]), new_end) for r in rows)

    def occupied_seats(self):
        """[(seat_id, student_id, updated_at)] -- admin occupant list."""
        with self._db() as db:
            rows = db.execute(
                "SELECT seat_id,student_id,updated_at FROM seats WHERE status='occupied' ORDER BY seat_id"
            ).fetchall()
        return [(r["seat_id"], r["student_id"] or "—", r["updated_at"]) for r in rows]

    def reservation_logs(self, search="", limit=2000):
        """[(timestamp, seat_id, action, student_id, details)], newest first.
        `search` matches part of a seat id or student number."""
        search = (search or "").strip().lower()
        with self._db() as db:
            if search:
                rows = db.execute(
                    "SELECT timestamp,seat_id,action,student_id,details FROM reservation_logs "
                    "WHERE instr(lower(seat_id),?)>0 OR instr(lower(student_id),?)>0 "
                    "ORDER BY id DESC LIMIT ?", (search, search, limit)).fetchall()
            else:
                rows = db.execute(
                    "SELECT timestamp,seat_id,action,student_id,details FROM reservation_logs "
                    "ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [tuple(r) for r in rows]

    # ------------------------------------------------------------------ student actions
    def reserve(self, seat_id, student_number, date_str, start_dt, duration_hours):
        try:
            student_number = normalize_student_id(student_number)
        except ValueError as exc:
            return False, str(exc)
        if start_dt < datetime.now() - timedelta(minutes=1):
            return False, "That start time has already passed. Please choose a later time."
        end_dt = start_dt + timedelta(hours=duration_hours)
        with self._db(write=True) as db:
            count = db.execute("SELECT COUNT(*) FROM reservations WHERE date=?", (date_str,)).fetchone()[0]
            if count >= MAX_RESERVATIONS_PER_DAY:
                return False, "This date is fully booked (Maximum 5 reservations allowed per day)."
            rows = db.execute(
                'SELECT start, "end" FROM reservations WHERE seat_id=? AND date=?', (seat_id, date_str)
            ).fetchall()
            if any(max(datetime.fromisoformat(r["start"]), start_dt) <
                   min(datetime.fromisoformat(r["end"]), end_dt) for r in rows):
                return False, "The selected time slot overlaps with an existing reservation for this seat."
            now = datetime.now().astimezone().isoformat()
            db.execute(
                'INSERT INTO reservations(seat_id,student_id,date,start,"end",created_at) VALUES(?,?,?,?,?,?)',
                (seat_id, student_number, date_str, start_dt.isoformat(), end_dt.isoformat(), now),
            )
            self._log(db, seat_id, "reservation_created", student_number,
                      f"{date_str} {start_dt:%H:%M}–{end_dt:%H:%M}")
        return True, f"Seat {seat_id} successfully reserved for {date_str}!"

    def occupy(self, seat_id, student_number):
        """Student check-in. Also records the login in student_login_log.csv."""
        try:
            student_number = normalize_student_id(student_number)
        except ValueError as exc:
            return False, str(exc)
        with self._db(write=True) as db:
            status, holder = self._state(db, seat_id, _now_iso())
            if status == "occupied":
                return False, "This seat is already occupied."
            if status == "reserved" and holder != student_number:
                return False, ("This seat is reserved by library staff." if not holder
                               else "This seat is reserved by another student.")
            if status == "reserved":
                # The holder is checking in: that reservation is now used up.
                cur = db.execute(
                    'DELETE FROM reservations WHERE id = (SELECT id FROM reservations '
                    'WHERE seat_id=? AND student_id=? AND "end" > ? ORDER BY start LIMIT 1)',
                    (seat_id, student_number, _now_iso()),
                )
                if cur.rowcount:
                    self._log(db, seat_id, "reservation_checked_in", student_number, "Reservation used")
            now = datetime.now().astimezone().isoformat()
            db.execute(
                "INSERT INTO seats(seat_id,status,student_id,updated_at) VALUES(?,?,?,?) "
                "ON CONFLICT(seat_id) DO UPDATE SET status=excluded.status,student_id=excluded.student_id,"
                "updated_at=excluded.updated_at",
                (seat_id, "occupied", student_number, now),
            )
            self._log(db, seat_id, "occupied", student_number, "Student occupied seat")
        # Passive login record. A locked CSV (e.g. open in Excel) must not block the seat.
        try:
            record_student_login(student_number, seat_id.partition("-")[0])
        except OSError as exc:
            self.log_reservation_event(seat_id, "login_log_failed", student_number, str(exc))
        return True, f"Seat {seat_id} occupied."

    def release(self, seat_id, student_number):
        """Student check-out (occupied seat) or cancellation (reserved seat)."""
        try:
            student_number = normalize_student_id(student_number)
        except ValueError as exc:
            return False, str(exc)
        with self._db(write=True) as db:
            status, holder = self._state(db, seat_id, _now_iso())
            if status == "available":
                return False, "This seat is already available."
            if holder != student_number:
                if status == "occupied":
                    return False, "Only the student who logged into this seat can check out."
                return False, ("This seat is reserved by library staff." if not holder
                               else "Only the student who reserved this seat can cancel the reservation.")
            now = datetime.now().astimezone().isoformat()
            if status == "occupied":
                db.execute(
                    "UPDATE seats SET status='available', student_id='', updated_at=? WHERE seat_id=?",
                    (now, seat_id),
                )
                self._log(db, seat_id, "released", student_number, "Student released seat")
                return True, f"Seat {seat_id} checked out. Thank you!"
            db.execute("DELETE FROM reservations WHERE seat_id=? AND student_id=?", (seat_id, student_number))
            db.execute(
                "UPDATE seats SET status='available', student_id='', updated_at=? WHERE seat_id=? AND status='reserved'",
                (now, seat_id),
            )
            self._log(db, seat_id, "reservation_cancelled", student_number, "Student cancelled reservation")
            return True, f"Your reservation for seat {seat_id} has been cancelled."

    # ------------------------------------------------------------------ librarian override
    def set_status(self, seat_id, status, student_id="", actor="librarian"):
        """Librarian override: change a seat to any status, no matter who set it before."""
        if status not in VALID_STATUSES:
            raise ValueError("Invalid seat status.")
        student_id = (student_id or "").strip()
        if student_id:
            student_id = normalize_student_id(student_id)
        if status == "available":
            student_id = ""
        with self._db(write=True) as db:
            previous, _ = self._state(db, seat_id, _now_iso())
            cleared = 0
            if status == "available":
                cleared = db.execute("DELETE FROM reservations WHERE seat_id=?", (seat_id,)).rowcount
            db.execute(
                "INSERT INTO seats(seat_id,status,student_id,updated_at) VALUES(?,?,?,?) "
                "ON CONFLICT(seat_id) DO UPDATE SET status=excluded.status,student_id=excluded.student_id,"
                "updated_at=excluded.updated_at",
                (seat_id, status, student_id, datetime.now().astimezone().isoformat()),
            )
            details = f"{previous} → {status}"
            if cleared:
                details += f" (cleared {cleared} reservation{'s' if cleared != 1 else ''})"
            self._log(db, seat_id, f"{actor}_status_override", student_id, details)
