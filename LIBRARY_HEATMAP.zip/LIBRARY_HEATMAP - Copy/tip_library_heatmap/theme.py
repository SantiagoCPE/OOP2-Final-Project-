import os

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor, QPalette

ROOT = os.path.dirname(os.path.abspath(__file__))
QSS_PATH = os.path.join(ROOT, "style.qss")


def load_stylesheet():
    with open(QSS_PATH, encoding="utf-8") as handle:
        return handle.read()


def _light_palette():
    pal = QPalette()
    roles = {
        QPalette.ColorRole.Window: "#ffffff",
        QPalette.ColorRole.WindowText: "#191919",
        QPalette.ColorRole.Base: "#ffffff",
        QPalette.ColorRole.AlternateBase: "#fbf8eb",
        QPalette.ColorRole.Text: "#111111",
        QPalette.ColorRole.Button: "#ffffff",
        QPalette.ColorRole.ButtonText: "#111111",
        QPalette.ColorRole.ToolTipBase: "#fffdf5",
        QPalette.ColorRole.ToolTipText: "#111111",
        QPalette.ColorRole.Highlight: "#ffcc00",
        QPalette.ColorRole.HighlightedText: "#111111",
        QPalette.ColorRole.PlaceholderText: "#888888",
    }
    for role, colour in roles.items():
        pal.setColor(role, QColor(colour))
    return pal


def apply_theme(app):
    try:
        app.styleHints().setColorScheme(Qt.ColorScheme.Light)  # Qt 6.8+
    except AttributeError:
        pass
    app.setPalette(_light_palette())
    app.setStyleSheet(load_stylesheet())
