"""Staff activity logs with the original floor-arrow paging interaction."""
import sqlite3
from datetime import datetime

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QColor, QPainter, QPainterPath, QPen
from PyQt6.QtWidgets import (
    QAbstractItemView, QDialog, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QPushButton, QSizePolicy, QTableWidget, QTableWidgetItem, QVBoxLayout,
)

from core.activity_logs import read_student_logins, read_events

FLOORS = (
    ("first", "First Floor"),
    ("right", "Second Floor (Right Wing)"),
    ("left", "Second Floor (Left Wing)"),
)
FLOOR_LABELS = dict(FLOORS)
UNKNOWN = "__unknown__"


def _format_time(value):
    try:
        return datetime.fromisoformat(str(value)).strftime("%b %d, %Y  %I:%M:%S %p")
    except (TypeError, ValueError):
        return str(value)


class FloorArrowButton(QPushButton):
    """Tall left/right chevron button matching the former staff log dialogs."""
    def __init__(self, direction, parent=None):
        super().__init__(parent)
        self.direction = direction
        self.setObjectName("floorArrow")
        self.setFixedWidth(44)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setAutoDefault(False)

    def paintEvent(self, event):
        super().paintEvent(event)
        pen = QPen(QColor("#111111") if self.isEnabled() else QColor("#cfc8b4"), 3.4)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        cx, cy, d = self.width() / 2, self.height() / 2, self.direction
        path = QPainterPath()
        path.moveTo(cx - d * 5, cy - 12)
        path.lineTo(cx + d * 5, cy)
        path.lineTo(cx - d * 5, cy + 12)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPath(path)
        painter.end()


class FloorPagedLogDialog(QDialog):
    REFRESH_MS = 2000

    def __init__(self, title, subtitle, headers, search_hint, fetch_rows, parent=None):
        super().__init__(parent)
        self._fetch_rows = fetch_rows  # returns [(floor_key, row_tuple), ...]
        self._pages = [key for key, _ in FLOORS]
        self._page = self._pages[0]
        self._last_rows = None
        self.setObjectName("staffDialog")
        self.setWindowTitle(title)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.resize(900, 540)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 18)
        layout.setSpacing(10)
        heading = QLabel(title); heading.setObjectName("dialogTitle")
        sub = QLabel(subtitle); sub.setObjectName("dialogSub"); sub.setWordWrap(True)
        layout.addWidget(heading); layout.addWidget(sub)

        self.search = QLineEdit()
        self.search.setPlaceholderText(search_hint)
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self.reload)
        layout.addWidget(self.search)

        self.floor_label = QLabel("")
        self.floor_label.setObjectName("floorTitle")
        layout.addWidget(self.floor_label, 0, Qt.AlignmentFlag.AlignHCenter)

        self.table = QTableWidget(0, len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setStretchLastSection(True)

        self.prev_button = FloorArrowButton(-1)
        self.prev_button.clicked.connect(lambda: self.step_floor(-1))
        self.next_button = FloorArrowButton(1)
        self.next_button.clicked.connect(lambda: self.step_floor(1))
        body = QHBoxLayout(); body.setSpacing(8)
        body.addWidget(self.prev_button); body.addWidget(self.table, 1); body.addWidget(self.next_button)
        layout.addLayout(body, 1)

        footer = QHBoxLayout()
        self.count_label = QLabel(""); self.count_label.setObjectName("dialogCount")
        footer.addWidget(self.count_label, 1)
        refresh = QPushButton("Refresh"); refresh.setObjectName("secondary")
        refresh.clicked.connect(lambda: self.reload(force=True))
        close = QPushButton("Close"); close.clicked.connect(self.close)
        footer.addWidget(refresh); footer.addWidget(close); layout.addLayout(footer)

        self._timer = QTimer(self)
        self._timer.setInterval(self.REFRESH_MS)
        self._timer.timeout.connect(self.reload)
        self._timer.start()
        self.reload(force=True)

    def step_floor(self, delta):
        index = self._pages.index(self._page) + delta
        if 0 <= index < len(self._pages):
            self._page = self._pages[index]
            self.reload(force=True, reset_scroll=True)

    def _sync_floor_controls(self):
        index = self._pages.index(self._page)
        name = "Unknown floor" if self._page == UNKNOWN else FLOOR_LABELS[self._page]
        self.floor_label.setText(f"{name}   •   {index + 1} of {len(self._pages)}")
        self.prev_button.setEnabled(index > 0)
        self.next_button.setEnabled(index < len(self._pages) - 1)
        self.prev_button.setToolTip(f"Previous: {FLOOR_LABELS[self._pages[index - 1]]}" if index > 0 else "")
        self.next_button.setToolTip(f"Next: {FLOOR_LABELS[self._pages[index + 1]]}" if index < len(self._pages) - 1 else "")

    def reload(self, *_args, force=False, reset_scroll=False):
        try:
            tagged = self._fetch_rows()
        except (sqlite3.Error, OSError):
            return
        pages = [key for key, _ in FLOORS]
        if any(floor not in pages for floor, _ in tagged):
            pages.append(UNKNOWN)
        self._pages = pages
        if self._page not in pages:
            self._page = pages[0]
        self._sync_floor_controls()
        rows = [row for floor, row in tagged if floor == self._page]
        needle = self.search.text().strip().lower()
        if needle:
            rows = [r for r in rows if any(needle in str(cell).lower() for cell in r)]
        if not force and rows == self._last_rows:
            return
        self._last_rows = rows
        bar = self.table.verticalScrollBar()
        position = 0 if reset_scroll else bar.value()
        self.table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            for c, value in enumerate(row):
                self.table.setItem(r, c, QTableWidgetItem(str(value)))
        bar.setValue(position)
        self.count_label.setText(f"{len(rows)} record{'s' if len(rows) != 1 else ''}")


def _student_rows():
    rows = read_student_logins()
    tagged = []
    for row in rows:
        if len(row) < 4 or row[0].strip().lower() in ("student number", "student id"):
            continue
        student, date, clock, floor = row[:4]
        tagged.append((str(floor).strip().lower(), (student, date, clock)))
    return tagged


def _reservation_rows():
    tagged = []
    for item in read_events():
        seat = str(item.get("seat", ""))
        floor = str(item.get("floor") or seat.split("-", 1)[0]).strip().lower()
        row = (
            _format_time(item.get("time", "")), seat,
            FLOOR_LABELS.get(floor, "Unknown floor"),
            item.get("action", ""), item.get("student", "—"), item.get("details", ""),
        )
        tagged.append((floor, row))
    return tagged


def student_log_dialog(parent=None):
    dialog = FloorPagedLogDialog(
        "Student Login Log",
        "Every student who logged in to use the heat map, newest first.",
        ["Student Number", "Date", "Time"],
        "Search by student number or date…",
        _student_rows,
        parent,
    )
    dialog.exec()


def reservation_log_dialog(parent=None):
    dialog = FloorPagedLogDialog(
        "Reservation Logs",
        "Records of every seat reservation, check-in, and check-out. Type a seat (e.g. first-012) to see its history.",
        ["Time", "Seat", "Location", "Action", "Student", "Details"],
        "Filter by seat, student number or action…",
        _reservation_rows,
        parent,
    )
    dialog.exec()
