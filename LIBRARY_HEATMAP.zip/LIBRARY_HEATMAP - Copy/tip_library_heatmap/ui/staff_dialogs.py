import sqlite3
from datetime import datetime

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QColor, QPainter, QPainterPath, QPen
from PyQt6.QtWidgets import (
    QAbstractItemView, QComboBox, QDialog, QHBoxLayout, QHeaderView, QLabel,
    QLineEdit, QMessageBox, QPushButton, QSizePolicy, QTableWidget, QTableWidgetItem,
    QVBoxLayout,
)

from core.seat_manager import FLOOR_NAMES, FLOOR_ORDER, seat_floor, seat_label
from student_login_logger import read_student_logins_by_floor

UNKNOWN_FLOOR = ""  # page key for records whose floor can't be determined


def format_timestamp(iso_text):
    try:
        return datetime.fromisoformat(iso_text).strftime("%b %d, %Y  %I:%M:%S %p")
    except (TypeError, ValueError):
        return str(iso_text)


class FloorArrowButton(QPushButton):
    """Tall chevron button at the left / right edge of a floor-paged dialog."""

    def __init__(self, direction, parent=None):
        super().__init__(parent)
        self.direction = direction  # -1 points left (previous floor), +1 points right (next floor)
        self.setObjectName("floorArrow")
        self.setFixedWidth(44)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setAutoDefault(False)  # Enter in the search box must never "click" an arrow

    def paintEvent(self, event):
        super().paintEvent(event)  # background / border from style.qss
        pen = QPen(QColor("#111111") if self.isEnabled() else QColor("#cfc8b4"), 3.4)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        cx, cy, d = self.width() / 2, self.height() / 2, self.direction
        chevron = QPainterPath()
        chevron.moveTo(cx - d * 5, cy - 12)
        chevron.lineTo(cx + d * 5, cy)
        chevron.lineTo(cx - d * 5, cy + 12)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPath(chevron)
        painter.end()


class LiveTableDialog(QDialog):
    REFRESH_MS = 2000 #forces data refresh every 2 seconds PASSIVELY

    def __init__(self, title, subtitle, headers, search_hint, fetch_rows, parent=None, floors=False):
        """With floors=True, fetch_rows returns [(floor_key, row), ...] and the dialog shows
        one floor at a time, with arrows at its left and right edge to move between floors."""
        super().__init__(parent)
        self._fetch_rows = fetch_rows
        self._by_floor = bool(floors)
        self._pages = list(FLOOR_ORDER) if self._by_floor else []
        self._page = self._pages[0] if self._pages else None
        self.setObjectName("staffDialog")
        self.setWindowTitle(title)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.resize(760, 520)
        self._last_rows = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 18)
        layout.setSpacing(10)

        heading = QLabel(title)
        heading.setObjectName("dialogTitle")
        sub = QLabel(subtitle)
        sub.setObjectName("dialogSub")
        sub.setWordWrap(True)
        layout.addWidget(heading)
        layout.addWidget(sub)

        self.search = QLineEdit()
        self.search.setPlaceholderText(search_hint)
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self.reload)
        layout.addWidget(self.search)

        if self._by_floor:
            self.floor_label = QLabel("")
            self.floor_label.setObjectName("floorTitle")
            layout.addWidget(self.floor_label, 0, Qt.AlignmentFlag.AlignHCenter)

        self.table = QTableWidget(0, len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setStretchLastSection(True)
        if self._by_floor:
            self.prev_button = FloorArrowButton(-1)
            self.prev_button.clicked.connect(lambda: self.step_floor(-1))
            self.next_button = FloorArrowButton(1)
            self.next_button.clicked.connect(lambda: self.step_floor(1))
            body = QHBoxLayout()
            body.setSpacing(8)
            body.addWidget(self.prev_button)
            body.addWidget(self.table, 1)
            body.addWidget(self.next_button)
            layout.addLayout(body, 1)
        else:
            layout.addWidget(self.table, 1)

        footer = QHBoxLayout()
        self.count_label = QLabel("")
        self.count_label.setObjectName("dialogCount")
        footer.addWidget(self.count_label, 1)
        refresh = QPushButton("Refresh")
        refresh.setObjectName("secondary")
        refresh.clicked.connect(lambda: self.reload(force=True))
        close = QPushButton("Close")
        close.clicked.connect(self.close)
        footer.addWidget(refresh)
        footer.addWidget(close)
        layout.addLayout(footer)

        self._timer = QTimer(self)
        self._timer.setInterval(self.REFRESH_MS)
        self._timer.timeout.connect(self.reload)
        self._timer.start()
        self.reload(force=True)

    # ------------------------------------------------------------------ floor paging
    def step_floor(self, delta):
        """Move to the previous (-1) or next (+1) floor; the arrows disable at either end."""
        if self._page not in self._pages:
            return
        target = self._pages.index(self._page) + delta
        if 0 <= target < len(self._pages):
            self._page = self._pages[target]
            self.reload(force=True, reset_scroll=True)

    def _sync_floor_controls(self):
        index = self._pages.index(self._page)
        self.floor_label.setText(f"{self._page_name(self._page)}   •   {index + 1} of {len(self._pages)}")
        self.prev_button.setEnabled(index > 0)
        self.next_button.setEnabled(index < len(self._pages) - 1)
        self.prev_button.setToolTip(f"Previous: {self._page_name(self._pages[index - 1])}" if index > 0 else "")
        self.next_button.setToolTip(
            f"Next: {self._page_name(self._pages[index + 1])}" if index < len(self._pages) - 1 else "")

    @staticmethod
    def _page_name(key):
        return FLOOR_NAMES.get(key, "Unknown floor")

    def _rows_for_page(self, tagged_rows):
        """Pick this floor's rows out of [(floor_key, row)] and keep the page list up to date."""
        pages = list(FLOOR_ORDER)
        stray = [floor not in FLOOR_ORDER for floor, _row in tagged_rows]
        if any(stray):
            pages.append(UNKNOWN_FLOOR)  # extra last page so a record with no known floor is never hidden
        self._pages = pages
        if self._page not in pages:
            self._page = pages[0]
        if self._page == UNKNOWN_FLOOR:
            return [row for (floor, row), is_stray in zip(tagged_rows, stray) if is_stray]
        return [row for floor, row in tagged_rows if floor == self._page]

    def reload(self, *_args, force=False, reset_scroll=False):
        try:
            rows = self._fetch_rows()
        except (sqlite3.Error, OSError):
            return  # file briefly locked by the other window; next tick will catch up
        if self._by_floor:
            rows = self._rows_for_page(rows)
            self._sync_floor_controls()
        needle = self.search.text().strip().lower()
        if needle:
            rows = [r for r in rows if any(needle in str(cell).lower() for cell in r)]
        if not force and rows == self._last_rows:
            return
        self._last_rows = rows
        bar = self.table.verticalScrollBar()
        position = 0 if reset_scroll else bar.value()
        self.table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            for c, value in enumerate(row):
                self.table.setItem(r, c, QTableWidgetItem(str(value)))
        bar.setValue(position)
        self.count_label.setText(f"{len(rows)} record{'s' if len(rows) != 1 else ''}")


class SeatOccupantsDialog(LiveTableDialog):
    """Admin only: which student number is sitting where."""

    def __init__(self, seat_manager, role, parent=None):
        if role != "admin":
            raise PermissionError("Seat occupant details are restricted to administrators.")

        def fetch():
            return [
                (seat_id, seat_floor(seat_id), student, format_timestamp(since))
                for seat_id, student, since in seat_manager.occupied_seats()
            ]

        super().__init__(
            "Seat Occupants",
            "Student numbers of everyone currently checked in to a seat.",
            ["Seat", "Location", "Student Number", "Checked in"],
            "Search by seat, floor or student number…",
            fetch,
            parent,
        )


class StudentLoginLogDialog(LiveTableDialog):
    """Admin only: every student who logged in to use the heat map, newest first."""
    def __init__(self, role, parent=None):
        if role != "admin":
            raise PermissionError("The student login log is restricted to administrators.")
        super().__init__(
            "Student Login Log",
            "Every student who logged in to use the heat map, newest first.",
            ["Student Number", "Date", "Time"],
            "Search by student number or date…",
            read_student_logins_by_floor,
            parent,
            floors=True,
        )


class SeatStatusDialog(QDialog):
    """Librarian only: set any seat to any status, whoever set it before."""

    STATUSES = (("Available", "available"), ("Reserved", "reserved"), ("Occupied", "occupied"))

    def __init__(self, seat_id, seat_manager, role, parent=None):
        if role != "librarian":
            raise PermissionError("Seat status can only be overridden by librarians.")
        super().__init__(parent)
        self.seat_id = seat_id
        self.seat_manager = seat_manager
        self.setObjectName("staffDialog")
        self.setWindowTitle("Update Seat Status")
        self.setModal(True)
        self.setFixedWidth(380)

        status, student = seat_manager.seat_info(seat_id)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 20)
        layout.setSpacing(10)

        heading = QLabel("Update Seat Status")
        heading.setObjectName("dialogTitle")
        current = f"Currently {status.title()}" + (f"  •  {student}" if student else "")
        sub = QLabel(f"{seat_label(seat_id)}\n{current}")
        sub.setObjectName("dialogSub")
        layout.addWidget(heading)
        layout.addWidget(sub)

        layout.addWidget(QLabel("New status"))
        self.status_box = QComboBox()
        for text, value in self.STATUSES:
            self.status_box.addItem(text, value)
        self.status_box.setCurrentIndex([v for _, v in self.STATUSES].index(status))
        self.status_box.currentIndexChanged.connect(self._sync_student_field)
        layout.addWidget(self.status_box)

        layout.addWidget(QLabel("Student number (optional)"))
        self.student_input = QLineEdit(student)
        self.student_input.setPlaceholderText("e.g. 24123456")
        layout.addWidget(self.student_input)

        row = QHBoxLayout()
        cancel = QPushButton("Cancel")
        cancel.setObjectName("secondary")
        cancel.clicked.connect(self.reject)
        save = QPushButton("Save")
        save.clicked.connect(self._save)
        row.addWidget(cancel)
        row.addWidget(save)
        layout.addLayout(row)
        self._sync_student_field()

    def _sync_student_field(self):
        self.student_input.setEnabled(self.status_box.currentData() != "available")

    def _save(self):
        status = self.status_box.currentData()
        try:
            self.seat_manager.set_status(self.seat_id, status, self.student_input.text(), actor="librarian")
        except ValueError as exc:
            QMessageBox.warning(self, "Check the student number", str(exc))
            return
        except sqlite3.Error as exc:
            QMessageBox.warning(self, "Database busy", f"Could not save right now, please try again.\n\n{exc}")
            return
        self.accept()
