import hmac
import os

from PyQt6.QtCore import Qt, QSettings
from PyQt6.QtGui import QPixmap
from PyQt6.QtWidgets import (
    QCheckBox, QFrame, QHBoxLayout, QLabel, QLineEdit, QMainWindow, QPushButton,
    QStackedWidget, QVBoxLayout, QWidget,
)

from ui.main_window import LibraryHeatMapWindow
from ui.support_dialog import SupportDialog

ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")

CREDENTIALS = {
    "admin": ("admin123", "adminlogin"),
    "librarian": ("library123", "librarylogin"),
}

ROLES = (
    ("librarian", "\U0001F4D6  Librarian", "SIGN IN AS LIBRARIAN  →"),
    ("admin", "\U0001F464  Administrator", "SIGN IN AS ADMINISTRATOR  →"),
)

WINDOW_SIZE = (1060, 683)
HEADER_HEIGHT = 60
FOOTER_HEIGHT = 26
MODE_BAR_SIZE = (329, 38)
FORM_WIDTH = 185
FIELD_HEIGHT = 34
BUTTON_HEIGHT = 35


class LoginForm(QWidget):
    def __init__(self, role, button_text, on_submit, on_forgot, parent=None):
        super().__init__(parent)
        self.role = role
        self.setObjectName("loginForm")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)

        col = QVBoxLayout(self)
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(0)

        label = QLabel("USERNAME")
        label.setObjectName("fieldLabel")
        col.addWidget(label)
        col.addSpacing(3)

        self.username = QLineEdit()
        self.username.setObjectName("identityInput")
        self.username.setPlaceholderText("Enter your username")
        self.username.setFixedHeight(FIELD_HEIGHT)
        col.addWidget(self.username)
        col.addSpacing(4)

        hint = QLabel("Authorized library staff only")
        hint.setObjectName("fieldHint")
        col.addWidget(hint)
        col.addSpacing(7)

        label = QLabel("PASSWORD")
        label.setObjectName("fieldLabel")
        col.addWidget(label)
        col.addSpacing(3)

        pw_row = QHBoxLayout()
        pw_row.setContentsMargins(0, 0, 0, 0)
        pw_row.setSpacing(0)
        self.password = QLineEdit()
        self.password.setObjectName("passwordInput")
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        self.password.setPlaceholderText("Enter your password")
        self.password.setFixedHeight(FIELD_HEIGHT)
        self.eye = QPushButton("\U0001F441")
        self.eye.setObjectName("eyeButton")
        self.eye.setFixedSize(FIELD_HEIGHT, FIELD_HEIGHT)
        self.eye.setCursor(Qt.CursorShape.PointingHandCursor)
        self.eye.setToolTip("Show / hide password")
        self.eye.clicked.connect(self._toggle_password)
        pw_row.addWidget(self.password, 1)
        pw_row.addWidget(self.eye)
        col.addLayout(pw_row)
        col.addSpacing(10)

        options = QHBoxLayout()
        options.setContentsMargins(0, 0, 0, 0)
        self.remember = QCheckBox("Remember Username")
        self.remember.setObjectName("rememberCheck")
        forgot = QPushButton("Forgot Password?")
        forgot.setObjectName("textButton")
        forgot.setCursor(Qt.CursorShape.PointingHandCursor)
        forgot.clicked.connect(on_forgot)
        options.addWidget(self.remember)
        options.addStretch(1)
        options.addWidget(forgot)
        col.addLayout(options)
        col.addSpacing(11)

        self.submit = QPushButton(button_text)
        self.submit.setObjectName("loginButton")
        self.submit.setFixedHeight(BUTTON_HEIGHT)
        self.submit.setCursor(Qt.CursorShape.PointingHandCursor)
        self.submit.clicked.connect(on_submit)
        col.addWidget(self.submit)

        self.status = QLabel("")
        self.status.setObjectName("statusMessage")
        self.status.setAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
        self.status.setWordWrap(True)
        col.addWidget(self.status)
        col.addStretch(1)

        self.username.returnPressed.connect(self.password.setFocus)
        self.password.returnPressed.connect(on_submit)

    def _toggle_password(self):
        hidden = self.password.echoMode() == QLineEdit.EchoMode.Password
        self.password.setEchoMode(QLineEdit.EchoMode.Normal if hidden else QLineEdit.EchoMode.Password)


class StaffLoginWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setObjectName("staffLoginWindow")
        self.setWindowTitle("TIP Integrated Library Services")
        self.resize(*WINDOW_SIZE)
        self.setMinimumSize(760, 560)
        self.settings = QSettings("TIP", "IntegratedLibraryStaffPortal")
        self.heatmap = None
        self.role = ROLES[0][0]

        root = QWidget()
        root.setObjectName("root")
        root.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        outer.addWidget(self._build_header())
        outer.addWidget(self._build_content(), 1)
        outer.addWidget(self._build_footer())

        self._restore_remembered_usernames()
        self._select_role(self.role)

    # ------------------------------------------------------------------ layout
    def _build_header(self):
        header = QFrame()
        header.setObjectName("header")
        header.setFixedHeight(HEADER_HEIGHT)
        row = QHBoxLayout(header)
        row.setContentsMargins(20, 0, 20, 0)
        row.setSpacing(13)

        logo = QLabel()
        logo.setFixedSize(46, 35)
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo.setStyleSheet("background:white;border:1px solid #111111")
        pix = QPixmap(os.path.join(ASSETS, "tip_logo.png"))
        if not pix.isNull():
            logo.setPixmap(pix.scaled(44, 33, Qt.AspectRatioMode.KeepAspectRatio,
                                      Qt.TransformationMode.SmoothTransformation))
        row.addWidget(logo)

        brand = QVBoxLayout()
        brand.setSpacing(10)
        brand.setContentsMargins(0, 0, 0, 0)
        title = QLabel("TECHNOLOGICAL INSTITUTE OF THE PHILIPPINES")
        title.setObjectName("instituteTitle")
        subtitle = QLabel("Integrated Library Services")
        subtitle.setObjectName("instituteSubtitle")
        brand.addStretch(1)
        brand.addWidget(title)
        brand.addWidget(subtitle)
        brand.addStretch(1)
        row.addLayout(brand, 1)

        support = QPushButton("\U0001F3A7  Support")
        support.setObjectName("supportButton")
        support.setFixedSize(85, 28)
        support.setCursor(Qt.CursorShape.PointingHandCursor)
        support.clicked.connect(self.open_support)
        row.addWidget(support)
        return header

    def _build_content(self):
        content = QWidget()
        content.setObjectName("contentArea")
        content.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        col = QVBoxLayout(content)
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(0)
        col.addStretch(7)

        mode_bar = QFrame()
        mode_bar.setObjectName("modeBar")
        mode_bar.setFixedSize(*MODE_BAR_SIZE)
        bar = QHBoxLayout(mode_bar)
        bar.setContentsMargins(4, 4, 4, 4)
        bar.setSpacing(4)
        self.mode_buttons = {}
        for role, text, _ in ROLES:
            button = QPushButton(text)
            button.setObjectName("modeButton")
            button.setProperty("active", False)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.clicked.connect(lambda _checked=False, r=role: self._select_role(r))
            bar.addWidget(button, 1)
            self.mode_buttons[role] = button
        col.addWidget(mode_bar, 0, Qt.AlignmentFlag.AlignHCenter)
        col.addSpacing(22)

        self.pages = QStackedWidget()
        self.pages.setObjectName("loginPages")
        self.pages.setFixedWidth(FORM_WIDTH)
        self.forms = {}
        for role, _, button_text in ROLES:
            form = LoginForm(role, button_text, self.login, self.open_support)
            self.pages.addWidget(form)
            self.forms[role] = form
        col.addWidget(self.pages, 0, Qt.AlignmentFlag.AlignHCenter)
        col.addStretch(13)
        return content

    def _build_footer(self):
        footer = QLabel("© 2026 Technological Institute of the Philippines. All Rights Reserved.")
        footer.setObjectName("footer")
        footer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        footer.setFixedHeight(FOOTER_HEIGHT)
        return footer

    # ------------------------------------------------------------------ behaviour
    def _restore_remembered_usernames(self):
        for role, form in self.forms.items():
            saved = self.settings.value(f"{role}/username", "")
            if saved:
                form.username.setText(str(saved))
                form.remember.setChecked(True)

    def _select_role(self, role):
        self.role = role
        self.pages.setCurrentWidget(self.forms[role])
        for key, button in self.mode_buttons.items():
            button.setProperty("active", key == role)
            button.style().unpolish(button)  # re-evaluate the [active="true"] rule
            button.style().polish(button)
        for form in self.forms.values():
            form.password.clear()
            form.status.clear()
        form = self.forms[role]
        (form.password if form.username.text() else form.username).setFocus()

    def open_support(self):
        SupportDialog(self).exec()

    def login(self):
        form = self.forms[self.role]
        expected_user, expected_password = CREDENTIALS[self.role]
        typed_user = form.username.text().strip()
        user_ok = hmac.compare_digest(typed_user.encode(), expected_user.encode())
        pass_ok = hmac.compare_digest(form.password.text().encode(), expected_password.encode())
        if not (user_ok and pass_ok):
            form.status.setText("Incorrect username or password.")
            form.password.clear()
            form.password.setFocus()
            return

        if form.remember.isChecked():
            self.settings.setValue(f"{self.role}/username", typed_user)
        else:
            self.settings.remove(f"{self.role}/username")
        form.password.clear()
        form.status.clear()

        self.heatmap = LibraryHeatMapWindow(role=self.role)
        self.heatmap.logged_out.connect(self._on_logged_out)
        self.heatmap.show()
        self.hide()

    def _on_logged_out(self):
        self._select_role(self.role)
        self.show()
        self.raise_()
        self.activateWindow()
