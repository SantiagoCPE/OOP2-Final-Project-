from core.seat_manager import ACTION_LABELS, seat_floor
from ui.staff_dialogs import LiveTableDialog


class ReservationLogsDialog(LiveTableDialog):
    def __init__(self, seat_manager, role, parent=None):
        if role != "librarian":
            raise PermissionError("Reservation logs are restricted to librarians.")

        def fetch():
            rows = []
            for timestamp, seat_id, action, student, details in seat_manager.reservation_logs():
                label = ACTION_LABELS.get(action, action.replace("_", " ").capitalize())
                rows.append((
                    seat_id.partition("-")[0],  # floor key: which page this record belongs on
                    (timestamp, seat_id, seat_floor(seat_id), label, student or "\u2014", details),
                ))
            return rows

        super().__init__(
            "Reservation Logs",
            "Records of every seat reservation, check-in, and check-out. "
            "Type a seat (e.g. first-012) to see the history of that one seat.",
            ["Time", "Seat", "Location", "Action", "Student", "Details"],
            "Filter by seat, student number or action\u2026",
            fetch,
            parent,
            floors=True,
        )
        self.resize(900, 540)
