import sys
from PyQt6.QtWidgets import QApplication
from theme import apply_theme
from ui.main_window import LibraryHeatMapWindow

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setApplicationName("TIP Library Space Heat Map")
    apply_theme(app)
    window = LibraryHeatMapWindow(role="student")
    window.show()
    sys.exit(app.exec())
