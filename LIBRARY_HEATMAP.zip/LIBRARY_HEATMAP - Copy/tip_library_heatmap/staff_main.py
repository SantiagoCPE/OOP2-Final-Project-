import sys
from PyQt6.QtWidgets import QApplication
from staff_login import StaffLoginWindow
from theme import apply_theme

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setApplicationName("TIP Integrated Library Services Staff Portal")
    apply_theme(app)
    window = StaffLoginWindow()
    window.show()
    sys.exit(app.exec())
