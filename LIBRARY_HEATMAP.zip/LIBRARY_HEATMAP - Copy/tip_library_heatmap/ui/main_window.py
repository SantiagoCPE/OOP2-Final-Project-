import json
import os
import sqlite3
import sys
import time
#forces imports to assets directory
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(ROOT, "assets")
sys.path.insert(0, ROOT)

from PyQt6.QtCore import Qt, QRect, QRectF, QSize, QTimer, QPropertyAnimation, QEasingCurve, QPoint, pyqtSignal
from PyQt6.QtGui import QAction, QIcon, QPixmap, QPainter, QColor, QPen, QPainterPath
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QMessageBox, QDialog, QVBoxLayout, QLabel,
    QPushButton, QHBoxLayout, QFrame, QGridLayout, QMenu, QSizePolicy
)

from core.seat_manager import SeatManager
from theme import load_stylesheet
from ui.support_dialog import SupportDialog
from ui.reservation_dialog import SeatReservationDialog
from ui.reservation_logs import ReservationLogsDialog
from ui.staff_dialogs import SeatOccupantsDialog, SeatStatusDialog, StudentLoginLogDialog

FLOORS = [
    ("first", "First Floor", "01"),
    ("right", "Second Floor", "RIGHT WING"),
    ("left", "Second Floor", "LEFT WING"),
]

FLOOR_FILES = {
    "first": ("", QRect(152, 88, 886, 497)),
    "right": ("", QRect(151, 88, 885, 496)),
    "left": ("", QRect(151, 88, 889, 496)),
}

ROLES = ("student", "admin", "librarian")
ROLE_TITLES = {"student": "", "admin": " | Administrator", "librarian": " | Librarian"}
ROLE_SUBTITLES = {"student": "", "admin": "  \u2022  Administrator View", "librarian": "  \u2022  Librarian View"}
ROLE_NAMES = {"admin": "Administrator", "librarian": "Librarian"}

AVATAR_SIZE = 34
AVATAR_FILE = "default_profile.png"


def default_avatar(size=AVATAR_SIZE):
    """The default (empty) profile picture, clipped to a circle with a thin outline.
    Uses assets/default_profile.png; draws an equivalent picture if the file is missing."""
    scale = 2  # drawn at 2x so it stays sharp on high-DPI screens
    px = size * scale
    out = QPixmap(px, px)
    out.fill(Qt.GlobalColor.transparent)
    p = QPainter(out)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
    clip = QPainterPath()
    clip.addEllipse(0, 0, px, px)
    p.setClipPath(clip)
    picture = QPixmap(os.path.join(ASSETS, AVATAR_FILE))
    if not picture.isNull():
        # The grey disc has a thin white margin inside the file; crop it off so the disc fills the circle.
        margin = round(min(picture.width(), picture.height()) * 0.045)
        source = QRectF(picture.rect()).adjusted(margin, margin, -margin, -margin)
        p.drawPixmap(QRectF(0, 0, px, px), picture, source)
    else:
        p.fillRect(QRectF(0, 0, px, px), QColor("#a6a6a6"))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#f2f2f2"))
        p.drawEllipse(QRectF(px * .32, px * .17, px * .36, px * .36))
        p.drawEllipse(QRectF(px * .16, px * .60, px * .68, px * .60))
    p.setClipping(False)
    ring = QPen(QColor("#111111"), 1.6 * scale)
    p.setPen(ring)
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawEllipse(QRectF(ring.widthF() / 2, ring.widthF() / 2, px - ring.widthF(), px - ring.widthF()))
    p.end()
    out.setDevicePixelRatio(scale)
    return out


class AccountButton(QPushButton):
    """Header account widget: profile picture + role. Darkens on hover, opens `menu` when clicked."""

    def __init__(self, label, menu, parent=None):
        super().__init__(f"{label}  \u25be", parent)
        self.menu = menu
        self._closed_at = 0.0
        self._ignore_click = False
        self.setObjectName("accountButton")
        self.setProperty("open", False)
        self.setIcon(QIcon(default_avatar()))
        self.setIconSize(QSize(AVATAR_SIZE, AVATAR_SIZE))
        self.setFixedHeight(AVATAR_SIZE + 12)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip("Account")
        self.clicked.connect(self._on_click)
        menu.aboutToHide.connect(self._on_menu_hidden)

    def _set_open(self, is_open):
        self.setProperty("open", is_open)  # keeps the darkened look while the menu is showing
        self.style().unpolish(self)
        self.style().polish(self)

    def mousePressEvent(self, event):
        # Clicking the button again while the menu is open first dismisses the menu; that same
        # click must not immediately re-open it.
        self._ignore_click = (time.monotonic() - self._closed_at) < 0.25
        super().mousePressEvent(event)

    def _on_click(self):
        if self._ignore_click:
            self._ignore_click = False
            return
        self._set_open(True)
        # Drop the menu just under the button, right edges lined up.
        x = self.width() - self.menu.sizeHint().width()
        self.menu.popup(self.mapToGlobal(QPoint(x, self.height() + 6)))

    def _on_menu_hidden(self):
        self._closed_at = time.monotonic()
        self._set_open(False)


class SeatButton(QPushButton):
    """A clickable Qt button dynamically painted green (Available), yellow (Reserved), or red (Occupied)."""
    def __init__(self, seat_id, side_view, callback, parent=None):
        super().__init__(parent)
        self.seat_id = seat_id
        self.side_view = side_view
        self.seat_status = "available"
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setToolTip(f"Seat {seat_id} — Available")
        self.clicked.connect(lambda: callback(self.seat_id))
        self.setStyleSheet("QPushButton { background: transparent; border: none; padding: 0; } QPushButton:hover { background: rgba(255,204,0,35); }")
        self.setAccessibleName(f"Library seat {seat_id}")

    def update_status(self, status):
        if status == self.seat_status:
            return
        self.seat_status = status
        self.setToolTip(f"Seat {self.seat_id} — {status.title()}")
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(1.2, 1.2, -1.2, -1.2)

        # Dynamic Color Selection: Occupied = Red, Reserved = Yellow, Available = Green
        if self.seat_status == "occupied":
            fill = QColor("#ff575d")
        elif self.seat_status == "reserved":
            fill = QColor("#ffcc00")
        else:
            fill = QColor("#b8ff72")

        pen = QPen(QColor("#101010"))
        pen.setWidthF(max(1.1, min(2.0, min(r.width(), r.height()) * .075)))
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        p.setPen(pen)
        p.setBrush(fill)

        if self.side_view and r.width() > r.height() * .70:
            path = QPainterPath()
            path.moveTo(r.left()+r.width()*.22, r.top()+r.height()*.12)
            path.cubicTo(r.left()+r.width()*.06, r.top()+r.height()*.08,
                         r.left()+r.width()*.06, r.bottom()-r.height()*.08,
                         r.left()+r.width()*.22, r.bottom()-r.height()*.10)
            path.cubicTo(r.left()+r.width()*.30, r.bottom()-r.height()*.14,
                         r.left()+r.width()*.29, r.top()+r.height()*.14,
                         r.left()+r.width()*.22, r.top()+r.height()*.12)
            p.drawPath(path)
            p.drawRoundedRect(QRectF(r.left()+r.width()*.25, r.top()+r.height()*.22,
                                     r.width()*.68, r.height()*.56), r.width()*.09, r.height()*.09)
            sw, sh = r.width()*.40, max(2, r.height()*.12)
            sx = r.left()+r.width()*.49
            p.drawRoundedRect(QRectF(sx, r.top()+r.height()*.04, sw, sh), 2, 2)
            p.drawRoundedRect(QRectF(sx, r.bottom()-sh-r.height()*.04, sw, sh), 2, 2)
        else:
            band_h = max(2.4, r.height()*.20)
            body = QRectF(r.left(), r.top(), r.width(), r.height()-band_h*.52)
            radius = min(r.width()*.23, r.height()*.28)
            p.drawRoundedRect(body, radius, radius)
            p.drawRect(QRectF(r.left(), r.bottom()-band_h, r.width(), band_h))

        if self.underMouse():
            p.setBrush(Qt.BrushStyle.NoBrush)
            hover_pen = QPen(QColor("#e5ae00")); hover_pen.setWidthF(1.2)
            p.setPen(hover_pen); p.drawRoundedRect(r.adjusted(-.5,-.5,.5,.5), 3, 3)
        p.end()

class LegendSymbol(QWidget):
    def __init__(self, kind="chair", color="#b8ff72", parent=None):
        super().__init__(parent)
        self.kind = kind
        self.color = QColor(color)
        self.setFixedSize(28 if kind == "chair" else 54, 24)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        pen = QPen(QColor("#111111"), 1.25)
        p.setPen(pen)
        if self.kind == "desk":
            p.setBrush(QColor("#ffffff"))
            p.drawRect(QRectF(1.5, 3, self.width()-3, self.height()-6))
        elif self.kind == "side":
            p.setBrush(self.color)
            p.drawRoundedRect(QRectF(1, 4, 6, 16), 2, 2)
            p.drawRoundedRect(QRectF(7, 7, 17, 10), 2, 2)
            p.drawRoundedRect(QRectF(10, 1.5, 11, 4), 1.5, 1.5)
            p.drawRoundedRect(QRectF(10, 18, 11, 4), 1.5, 1.5)
        else:
            p.setBrush(self.color)
            p.drawRoundedRect(QRectF(3, 2, 21, 18), 4, 4)
            p.drawRect(QRectF(3, 15, 21, 4))
        p.end()


class FloorPlanWidget(QWidget):
    def __init__(self, floor_key, seat_manager, seat_callback, parent=None):
        super().__init__(parent)
        self.floor_key = floor_key
        self.seat_manager = seat_manager
        self.seat_callback = seat_callback
        self.setMinimumSize(540, 360)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        
        json_path = os.path.join(ROOT, "chair_positions.json")
        with open(json_path, encoding="utf-8") as f:
            self.positions = json.load(f)[floor_key]

        _, logical_rect = FLOOR_FILES[floor_key]
        self.source_crop = logical_rect
        self.plan_width = logical_rect.width()
        self.plan_height = logical_rect.height()
        self.buttons = []
        initial_statuses = self.seat_manager.all_statuses()
        for i, box in enumerate(self.positions, start=1):
            seat_id = f"{floor_key}-{i:03d}"
            side_view = box[2] >= 25 and box[3] >= 25
            button = SeatButton(seat_id, side_view, self.seat_callback, self)
            button.update_status(initial_statuses.get(seat_id, "available"))
            button._source_box = box
            self.buttons.append(button)
        self._layout_buttons()

    def resizeEvent(self, event):
        self._layout_buttons()
        super().resizeEvent(event)

    def _layout_buttons(self):
        if not self.buttons:
            return
        sx = self.width() / self.plan_width
        sy = self.height() / self.plan_height
        for button in self.buttons:
            x, y, w, h = button._source_box
            x -= self.source_crop.x(); y -= self.source_crop.y()
            button.setGeometry(round(x*sx), round(y*sy),
                               max(9, round(w*sx)), max(9, round(h*sy)))

    def refresh_seats(self, statuses=None):
        if statuses is None:
            statuses = self.seat_manager.all_statuses()
        for button in self.buttons:
            button.update_status(statuses.get(button.seat_id, "available"))

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.fillRect(self.rect(), QColor("#ffffff"))
        p.save()
        p.scale(self.width()/self.plan_width, self.height()/self.plan_height)

        black = QColor("#202020")
        white = QColor("#ffffff")
        green = QColor("#b8ff72")
        shelf_fill = QColor("#fdfdfd")
        p.setPen(QPen(black, 1.8))
        p.setBrush(white)

        def desk(x, y, w, h, line=1.8):
            p.setPen(QPen(black, line)); p.setBrush(white)
            p.drawRect(QRectF(x, y, w, h))

        def shelf(x, y, w, h, vertical=True):
            p.setPen(QPen(QColor("#777777"), 1.0)); p.setBrush(shelf_fill)
            p.drawRect(QRectF(x, y, w, h))
            p.setPen(QPen(QColor("#a0a0a0"), 1.0))
            if vertical:
                p.drawRect(QRectF(x+w*.43, y+5, max(2,w*.14), max(3,h-10)))
            else:
                p.drawRect(QRectF(x+5, y+h*.43, max(3,w-10), max(2,h*.14)))

        def side_panels(x, y, w, heights):
            yy = y
            p.setPen(QPen(black, 1.8)); p.setBrush(green)
            for h in heights:
                p.drawRect(QRectF(x, yy, w, h)); yy += h

        if self.floor_key == "first":
            p.setPen(QPen(black, 2.2)); p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawLine(151, 0, 205, 0)
            p.drawLine(151, 0, 151, 11)
            p.drawArc(QRectF(151, 0, 58, 58), -90*16, 90*16)
            p.save(); p.translate(131, 11); p.rotate(90)
            p.setPen(QPen(black, 1)); p.drawText(QRectF(0,0,60,18), Qt.AlignmentFlag.AlignCenter, "Entrance"); p.restore()
            desk(257, 0, 114, 36); desk(371, 0, 115, 36); desk(696, 0, 116, 36)
            side_panels(114, 77, 36, [83,84,84,84,83])
            for y,h in [(77,82),(159,84),(243,84),(327,84),(411,85)]: shelf(153,y,31,h)
            for x in (270,588):
                for y in (115,217,319,421): desk(x,y,115,36)
            for y,h in [(93,84),(209,84),(325,84)]: shelf(472,y,31,h)
            for y,h in [(69,84),(153,84),(237,84),(321,84),(405,92)]: shelf(777,y,31,h)

        elif self.floor_key == "right":
            p.setPen(QPen(black, 2.2)); p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawLine(82, 0, 82, 118)
            p.drawArc(QRectF(82, 0, 56, 58), 180*16, 90*16)
            p.drawLine(82, 0, 137, 0)
            p.drawText(QRectF(45, 25, 30, 70), Qt.AlignmentFlag.AlignCenter, "Entrance")
            desk(218,0,116,33); desk(334,0,116,33)
            desk(82,119,117,36); desk(82,295,117,37)
            p.setPen(QPen(black,1.8)); p.setBrush(white)
            p.drawRect(QRectF(82,155,79,140)); p.drawRect(QRectF(161,155,38,117))
            desk(576,7,115,36)
            for x in (318,576):
                for y in (116,215,314,413): desk(x,y,115,36)
            for y,h in [(0,80),(85,80),(170,80),(255,80),(340,80),(420,77)]: shelf(778,y,31,h)

        else:
            p.setPen(QPen(black, 2.2)); p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawLine(76, 0, 76, 34); p.drawLine(192, 0, 192, 34)
            p.drawArc(QRectF(76, 0, 58, 58), 180*16, 90*16)
            p.drawArc(QRectF(134, 0, 58, 58), -90*16, 90*16)
            p.drawText(QRectF(83, 0, 103, 20), Qt.AlignmentFlag.AlignCenter, "Entrance")
            desk(223,0,116,34); desk(339,0,116,34)
            side_panels(115,160,36,[84,84,84,85])
            for y,h in [(160,83),(243,84),(327,84),(411,85)]: shelf(153,y,31,h)
            for x in (270,588):
                for y in (115,217,319,421): desk(x,y,115,36)
            for y,h in [(93,84),(209,84),(325,84)]: shelf(472,y,31,h)
            for y,h in [(0,84),(84,84),(168,84),(252,84),(336,84),(420,77)]: shelf(780,y,30,h)

        p.setPen(QPen(QColor("#eeeeee"), 1)); p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRect(QRectF(.5,.5,self.plan_width-1,self.plan_height-1))
        p.restore(); p.end()

class FloorSlideArea(QWidget):
    def __init__(self, floors, parent=None):
        super().__init__(parent)
        self.pages = floors
        self.current_key = "first"
        self._animations = []
        for page in self.pages.values():
            page.setParent(self)
        self.pages[self.current_key].show()

    def resizeEvent(self, event):
        current = self.pages[self.current_key]
        current.setGeometry(0, 0, self.width(), self.height())
        super().resizeEvent(event)

    def show_floor(self, key):
        if key == self.current_key:
            return
        old_key = self.current_key
        old_page, new_page = self.pages[old_key], self.pages[key]
        direction = 1 if [x[0] for x in FLOORS].index(key) > [x[0] for x in FLOORS].index(old_key) else -1
        w, h = self.width(), self.height()
        new_page.setGeometry(direction*w, 0, w, h)
        new_page.show(); new_page.raise_()
        old_anim = QPropertyAnimation(old_page, b"pos", self)
        old_anim.setDuration(300); old_anim.setStartValue(QPoint(0, 0)); old_anim.setEndValue(QPoint(-direction*w, 0))
        old_anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        new_anim = QPropertyAnimation(new_page, b"pos", self)
        new_anim.setDuration(300); new_anim.setStartValue(QPoint(direction*w, 0)); new_anim.setEndValue(QPoint(0, 0))
        new_anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._animations = [old_anim, new_anim]
        old_anim.start(); new_anim.start()
        self.current_key = key
        def finish():
            old_page.hide(); old_page.move(0, 0)
            new_page.setGeometry(0, 0, self.width(), self.height())
            self._animations = []
        new_anim.finished.connect(finish)

class LibraryHeatMapWindow(QMainWindow):
    logged_out = pyqtSignal()

    def __init__(self, role='student'):
        super().__init__()
        if role not in ROLES:
            raise ValueError(f"Unknown role: {role!r}")
        self.role = role
        self._edit_mode = False
        self._staff_dialogs = {}
        self.setObjectName("heatMapWindow")
        self.setWindowTitle("TIP Integrated Library Services | Library Space Heat Map" + ROLE_TITLES[role])
        self.resize(1240, 760)
        self.setMinimumSize(1000, 650)
        self.seat_manager = SeatManager()
        # style.qss is normally applied app-wide by theme.apply_theme(); this only
        # covers the window being created in an app that skipped that step.
        app = QApplication.instance()
        if app is not None and not app.styleSheet():
            self.setStyleSheet(load_stylesheet())
        root = QWidget(); root.setObjectName("appRoot")
        outer = QVBoxLayout(root); outer.setContentsMargins(0,0,0,0); outer.setSpacing(0)
        outer.addWidget(self._build_header())
        body = QHBoxLayout(); body.setContentsMargins(0,0,0,0); body.setSpacing(0)
        body.addWidget(self._build_sidebar())
        self.floor_pages = {key: FloorPlanWidget(key, self.seat_manager, self.handle_seat_click) for key, _, _ in FLOORS}
        self.slide_area = FloorSlideArea(self.floor_pages)
        body.addWidget(self.slide_area, 1)
        body_wrap = QWidget(); body_wrap.setLayout(body); outer.addWidget(body_wrap, 1)
        outer.addWidget(self._build_footer())
        self.setCentralWidget(root)
        self.floor_buttons["first"].setChecked(True)
        self._add_role_tools()
        self._apply_role_permissions()
        self._update_seat_cursors()
        self.refresh_timer = QTimer(self)
        self.refresh_timer.setInterval(1000)
        self.refresh_timer.timeout.connect(self.refresh_shared_state)
        self.refresh_timer.start()

    def _build_header(self):
        header = QFrame(); header.setObjectName("heatHeader"); header.setFixedHeight(92)
        layout = QHBoxLayout(header); layout.setContentsMargins(24,10,24,10); layout.setSpacing(16)
        logo = QLabel(); logo.setFixedSize(76,60); logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pix = QPixmap(os.path.join(ASSETS, "tip_logo.png"))
        if not pix.isNull(): logo.setPixmap(pix.scaled(76,60,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        logo.setStyleSheet("background:white;border:1px solid #111")
        layout.addWidget(logo)
        brand = QVBoxLayout(); brand.setSpacing(2)
        title = QLabel("TECHNOLOGICAL INSTITUTE OF THE PHILIPPINES"); title.setObjectName("brandTitle")
        subtitle = QLabel("Integrated Library Services" + ROLE_SUBTITLES[self.role]); subtitle.setObjectName("brandSubtitle")
        brand.addWidget(title); brand.addWidget(subtitle); layout.addLayout(brand,1)
        if self.role in ("admin", "librarian"):
            layout.addWidget(self._build_account_button())
        support = QPushButton("◉  Support"); support.setObjectName("supportButton"); support.setCursor(Qt.CursorShape.PointingHandCursor)
        support.clicked.connect(self.open_support); layout.addWidget(support)
        return header

    def _build_account_button(self):
        """Account widget (replaces the old Log out button). Menu entries depend on the role:
        librarians get Reservation Logs, administrators get Student Login Log, both get Log out."""
        menu = QMenu(self)
        menu.setObjectName("accountMenu")
        # Frameless + translucent so the rounded corners from style.qss show cleanly.
        menu.setWindowFlag(Qt.WindowType.FramelessWindowHint, True)
        menu.setWindowFlag(Qt.WindowType.NoDropShadowWindowHint, True)
        menu.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        def add_entry(text, slot, enabled=True):
            action = QAction(text, menu)
            action.setEnabled(enabled)
            if enabled:
                action.triggered.connect(lambda _checked=False: slot())
            menu.addAction(action)

        add_entry(f"Signed in as {ROLE_NAMES[self.role]}", None, enabled=False)  # caption, not clickable
        menu.addSeparator()
        if self.role == "librarian":
            add_entry("Reservation Logs", self.show_reservation_logs)
        elif self.role == "admin":
            add_entry("Student Login Log", self.show_student_login_log)
        menu.addSeparator()
        add_entry("Log out", self.log_out)
        self.account_menu = menu
        self.account_button = AccountButton(ROLE_NAMES[self.role], menu)
        return self.account_button

    def _build_sidebar(self):
        sidebar = QFrame(); sidebar.setObjectName("sidebar"); sidebar.setFixedWidth(190)
        layout = QVBoxLayout(sidebar); layout.setContentsMargins(14,22,14,18); layout.setSpacing(10)
        title = QLabel("LIBRARY"); title.setObjectName("sectionTitle"); layout.addWidget(title)
        sub = QLabel("SELECT FLOOR"); sub.setObjectName("sectionSub"); layout.addWidget(sub); layout.addSpacing(12)
        self.floor_buttons = {}
        for key, name, wing in FLOORS:
            btn = QPushButton()
            btn.setObjectName("floorButton"); btn.setCheckable(True); btn.setAutoExclusive(True)
            btn.setText(name if key == "first" else f"{name}\n({wing.title()})")
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda checked=False, k=key: self.change_floor(k))
            layout.addWidget(btn); self.floor_buttons[key] = btn
        layout.addSpacing(24)
        legend_title = QLabel("Legend:"); legend_title.setObjectName("legendTitle"); layout.addWidget(legend_title)
        legend = QFrame(); legend.setObjectName("legendCard")
        leg = QGridLayout(legend); leg.setContentsMargins(6,6,6,6); leg.setHorizontalSpacing(4); leg.setVerticalSpacing(3)
        chairs_label = QLabel("Chairs"); chairs_label.setAlignment(Qt.AlignmentFlag.AlignCenter); chairs_label.setObjectName("legendHead")
        desk_label = QLabel("Desk"); desk_label.setAlignment(Qt.AlignmentFlag.AlignCenter); desk_label.setObjectName("legendHead")
        leg.addWidget(chairs_label,0,0,1,2); leg.addWidget(desk_label,0,2)
        leg.addWidget(LegendSymbol("chair", "#b8ff72"),1,0,Qt.AlignmentFlag.AlignCenter)
        leg.addWidget(LegendSymbol("side", "#b8ff72"),1,1,Qt.AlignmentFlag.AlignCenter)
        leg.addWidget(LegendSymbol("desk"),1,2,Qt.AlignmentFlag.AlignCenter)
        occupied = QLabel("Occupied"); occupied.setObjectName("legendOccupied")
        reserved = QLabel("Reserved"); reserved.setObjectName("legendReserved")
        available = QLabel("Available"); available.setObjectName("legendAvailable")
        leg.addWidget(occupied,2,0,1,2,Qt.AlignmentFlag.AlignCenter)
        leg.addWidget(reserved,2,2,Qt.AlignmentFlag.AlignCenter)
        leg.addWidget(available,3,0,1,3,Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(legend)
        self.role_tools_box = QWidget()
        self.role_tools = QVBoxLayout(self.role_tools_box)
        self.role_tools.setContentsMargins(0, 8, 0, 0)
        self.role_tools.setSpacing(5)
        self.role_tools_title = QLabel("STAFF TOOLS")
        self.role_tools_title.setObjectName("sectionSub")
        self.role_tools.addWidget(self.role_tools_title)
        layout.addWidget(self.role_tools_box)
        layout.addStretch(1)
        tip = QLabel("TIP\nINTEGRATED LIBRARY SERVICES"); tip.setObjectName("sidebarTip")
        layout.addWidget(tip)
        return sidebar

    def _build_footer(self):
        footer = QFrame(); footer.setObjectName("heatFooter"); footer.setFixedHeight(42)
        layout = QHBoxLayout(footer); layout.setContentsMargins(10,0,10,0)
        text = QLabel("© 2026 Technological Institute of the Philippines. All Rights Reserved.")
        text.setObjectName("footerText"); text.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(text); return footer

    def change_floor(self, key):
        self.floor_buttons[key].setChecked(True)
        self.slide_area.show_floor(key)

    def open_support(self):
        dialog = SupportDialog(self)
        dialog.exec()

    # ------------------------------------------------------------------ roles
    def _add_role_tools(self):
        """Sidebar tools. Students get none; each staff role gets its own set."""
        def tool(text, slot, checkable=False):
            button = QPushButton(text)
            button.setObjectName("toolButton")
            button.setCheckable(checkable)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.clicked.connect(slot)
            self.role_tools.addWidget(button)
            return button

        if self.role == "librarian":
            self.edit_status_button = tool("Update Seat Status", self.toggle_edit_mode, checkable=True)
            self.edit_status_button.setToolTip("Turn on, then click any seat on the map to change its status.")
        elif self.role == "admin":
            self.owner_list_button = tool("View Seat Occupants", self.show_occupants)

    def _apply_role_permissions(self):
        self.role_tools_box.setVisible(self.role in ("admin", "librarian"))

    def _update_seat_cursors(self):
        """Only show the hand cursor on seats that do something for this role."""
        interactive = self.role == "student" or (self.role == "librarian" and self._edit_mode)
        cursor = Qt.CursorShape.PointingHandCursor if interactive else Qt.CursorShape.ArrowCursor
        for page in self.floor_pages.values():
            for button in page.buttons:
                button.setCursor(cursor)

    def toggle_edit_mode(self, checked):
        self._edit_mode = bool(checked)
        self.edit_status_button.setText("Click a seat to edit\u2026" if self._edit_mode else "Update Seat Status")
        self._update_seat_cursors()

    def _open_single(self, key, factory):
        """Open a staff dialog once; a second click just brings it to the front."""
        existing = self._staff_dialogs.get(key)
        if existing is not None:
            existing.show()
            existing.raise_()
            existing.activateWindow()
            return
        try:
            dialog = factory()
        except PermissionError as exc:
            QMessageBox.warning(self, "Access denied", str(exc))
            return
        self._staff_dialogs[key] = dialog
        dialog.finished.connect(lambda _result=0, k=key: self._staff_dialogs.pop(k, None))
        dialog.show()

    def show_occupants(self):
        self._open_single("occupants", lambda: SeatOccupantsDialog(self.seat_manager, self.role, self))

    def show_student_login_log(self):
        self._open_single("student_log", lambda: StudentLoginLogDialog(self.role, self))

    def show_reservation_logs(self):
        self._open_single("reservation_logs", lambda: ReservationLogsDialog(self.seat_manager, self.role, self))

    def log_out(self):
        self.logged_out.emit()
        self.close()

    def closeEvent(self, event):
        self.refresh_timer.stop()
        for dialog in list(self._staff_dialogs.values()):
            dialog.close()
        super().closeEvent(event)

    # ------------------------------------------------------------------ seats + sync
    def handle_seat_click(self, seat_id):
        if self.role == "student":
            dialog = SeatReservationDialog(seat_id, self.seat_manager, self)
        elif self.role == "librarian" and self._edit_mode:
            try:
                dialog = SeatStatusDialog(seat_id, self.seat_manager, self.role, self)
            except PermissionError as exc:
                QMessageBox.warning(self, "Access denied", str(exc))
                return
        else:
            return  # admins and idle librarians use the sidebar tools instead
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.refresh_shared_state()

    def refresh_shared_state(self):
        """Runs every second: pull the latest seat states written by any other window."""
        try:
            statuses = self.seat_manager.all_statuses()
        except sqlite3.Error:
            return  # database briefly locked by the other window; try again next tick
        for page in self.floor_pages.values():
            page.refresh_seats(statuses)
