import os
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap
from PyQt6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QMainWindow, QPushButton,
                             QStackedWidget, QVBoxLayout, QWidget, QMenu, QToolButton)
from core import auth
from core.seat_manager import SeatManager
from ui.common import ask_yes_no
from ui.heatmap_page import ASSETS, HeatmapPage
from ui.pages import RolePage
from ui.support_dialog import SupportDialog
from ui.theme import APP_STYLES
from ui.staff_tools import student_log_dialog, reservation_log_dialog

class AppWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("TIP Integrated Library Services | Library Space Heat Map")
        self.resize(1240, 760); self.setMinimumSize(1000, 650); self.setStyleSheet(APP_STYLES)
        self.seat_manager = SeatManager(); self.heatmap = None
        root = QWidget(); root.setObjectName("appRoot")
        outer = QVBoxLayout(root); outer.setContentsMargins(0,0,0,0); outer.setSpacing(0)
        outer.addWidget(self._build_header())
        self.stack = QStackedWidget(); self.role_page = RolePage(); self.stack.addWidget(self.role_page)
        outer.addWidget(self.stack, 1)
        footer = QFrame(); footer.setObjectName("footer"); footer.setFixedHeight(42)
        fl = QHBoxLayout(footer); ft = QLabel("© 2026 Technological Institute of the Philippines. All Rights Reserved.")
        ft.setObjectName("footerText"); ft.setAlignment(Qt.AlignmentFlag.AlignCenter); fl.addWidget(ft)
        outer.addWidget(footer); self.setCentralWidget(root)
        self.role_page.student_logged_in.connect(lambda num: self.open_heatmap("student", num))
        self.role_page.staff_logged_in.connect(lambda kind, user: self.open_heatmap(kind, None))

    def _build_header(self):
        header = QFrame(); header.setObjectName("topHeader"); header.setFixedHeight(84)
        lay = QHBoxLayout(header); lay.setContentsMargins(24,10,24,10); lay.setSpacing(16)
        logo = QLabel(); logo.setFixedSize(76,58); logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pix = QPixmap(os.path.join(ASSETS,"tip_logo.png"))
        if not pix.isNull(): logo.setPixmap(pix.scaled(76,58,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        logo.setStyleSheet("background:white;border:1px solid #111")
        brand = QVBoxLayout(); brand.setSpacing(2)
        t = QLabel("TECHNOLOGICAL INSTITUTE OF THE PHILIPPINES"); t.setObjectName("brandTitle")
        sub = QLabel("Integrated Library Services"); sub.setObjectName("brandSubtitle")
        brand.addWidget(t); brand.addWidget(sub); lay.addWidget(logo); lay.addLayout(brand,1)
        self.account_button = QToolButton(); self.account_button.setText("👤 Librarian Profile  ▾")
        self.account_button.setObjectName("headerButton"); self.account_button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.account_menu = QMenu(self.account_button); self.account_button.setMenu(self.account_menu); self.account_button.hide()
        support = QPushButton("🎧  Support"); support.setObjectName("headerButton")
        support.setCursor(Qt.CursorShape.PointingHandCursor); support.clicked.connect(self.open_support)
        self.sign_out_btn = QPushButton("⎋  Sign out of the app"); self.sign_out_btn.setObjectName("signOutButton")
        self.sign_out_btn.setCursor(Qt.CursorShape.PointingHandCursor); self.sign_out_btn.clicked.connect(self.sign_out); self.sign_out_btn.hide()
        lay.addWidget(self.account_button); lay.addWidget(support); lay.addWidget(self.sign_out_btn)
        return header

    def open_heatmap(self, mode, student_number=None):
        self._close_heatmap(); self.heatmap = HeatmapPage(mode,self.seat_manager,student_number)
        self.stack.addWidget(self.heatmap); self.stack.setCurrentWidget(self.heatmap)
        self.account_menu.clear()
        if mode == "librarian":
            self.account_button.setText("👤 Librarian Profile  ▾")
            self.account_menu.addAction("📋 Student Login Logs",lambda: student_log_dialog(self))
            self.account_menu.addAction("📚 Reservation Logs",lambda: reservation_log_dialog(self))
            self.account_menu.addSeparator()
            self.account_menu.addAction("↻ Refresh Program",lambda: self.heatmap.force_refresh() if self.heatmap else None)
            self.account_button.show()
        else: self.account_button.hide()
        self.sign_out_btn.show()

    def _close_heatmap(self):
        if self.heatmap is not None:
            self.heatmap.stop(); self.stack.removeWidget(self.heatmap); self.heatmap.deleteLater(); self.heatmap=None

    def sign_out(self):
        if not ask_yes_no(self,"Sign out","Sign out of the app?",""): return
        self._close_heatmap(); self.account_button.hide(); self.sign_out_btn.hide(); self.stack.setCurrentWidget(self.role_page)

    def open_support(self):
        mode = self.heatmap.mode if self.heatmap else None
        messages = {
            "student":"For account problems, approach the library desk. Use the profile menu to refresh the seat display.",
            "entrance":"Entrance access can only log students in and out of chairs. Use Refresh Screen if the map looks out of date.",
            "librarian":"Librarian access can remove reservations from yellow chairs. Use Refresh Screen if the map looks out of date.",
        }
        message = messages.get(mode,"For account access or password assistance, contact the library support desk.")
        refresh = self.heatmap.force_refresh if self.heatmap else (lambda: False)
        SupportDialog(message,refresh,self,show_refresh=mode not in ("student",None)).exec()
