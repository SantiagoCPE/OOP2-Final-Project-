# TIP Library Space Heat Map

## Run
1. Install Python 3.10+.
2. Install dependencies: `pip install PyQt6`.
3. From this folder, run: `python main.py`.

## Demo staff credentials
- Administrator: `admin01` / `admin123`
- Librarian: `librarian01` / `library123`
- Entrance: `entrance01` / `entrance123`

Student access continues to use the existing 7-digit student-number workflow.

## Notes
- Seat state is stored in `library_space_heatmap/data/seat_state.json`.
- Student check-in history is stored in `library_space_heatmap/data/student_login_log.csv`.
- Reservation and seat activity history is stored in `library_space_heatmap/data/reservation_activity.json`.
- Seat-map passive refresh runs in the heatmap page at 350 ms intervals.
