from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton
from PyQt6.QtCore import Qt


class SupportDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Integrated Library Services Support")
        self.setMinimumWidth(360)
        self.setStyleSheet("""
            QDialog { background: #fffdf5; }
            QLabel { color: #191919; }
            QPushButton { background: #ffcc00; color: #111111; border: 1px solid #e3b900;
                          border-radius: 8px; padding: 9px 14px; font-weight: 800; }
            QPushButton:hover { background: #ffe77c; }
        """)
        layout = QVBoxLayout(self)
        message = QLabel(
            "For account access or library assistance, please approach the library support desk."
        )
        message.setWordWrap(True)
        layout.addWidget(message)
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        layout.addWidget(close)
