import csv
import os
import sqlite3
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
LOG_FILE = BASE_DIR / "student_login_log.csv"
DB_FILE = BASE_DIR / "library_shared_data.sqlite3"
# "Floor" holds the floor key ("first", "right" or "left") of the seat the student checked in to.
FIELDS = ["Student ID", "Login Date", "Login Time", "Floor"]

#Global declarations for VALID student credentials
ID_LENGTH = 7
ID_PREFIXES = ("24", "25")

# A CSV row and its check-in entry in the database are written within the same moment.
LEGACY_MATCH_SECONDS = 5


def normalize_student_id(student_id):
    cleaned = str(student_id).strip().replace("-", "").replace(" ", "") #strips hyphens and spaces
    if len(cleaned) != ID_LENGTH or not cleaned.isdigit() or not cleaned.startswith(ID_PREFIXES):
        raise ValueError("Student ID must be exactly 7 digits and start with 24 or 25.")
    return cleaned


# ---------------------------------------------------------------------- floor look-up for old rows
def _checkin_history():
    """[(datetime, student_id, floor_key)] for every check-in in the shared database."""
    try:
        conn = sqlite3.connect(DB_FILE.as_uri() + "?mode=ro", uri=True, timeout=5)
        try:
            rows = conn.execute(
                "SELECT timestamp, seat_id, student_id FROM reservation_logs WHERE action='occupied'"
            ).fetchall()
        finally:
            conn.close()
    except sqlite3.Error:
        return []
    history = []
    for stamp, seat_id, student in rows:
        try:
            when = datetime.strptime(str(stamp)[:19], "%Y-%m-%d %H:%M:%S")
        except ValueError:
            continue
        history.append((when, student, str(seat_id).partition("-")[0]))
    return history


def _guess_floor(student_id, date_text, time_text, history):
    """Floor of the check-in that produced this CSV row, or "" if it can't be matched."""
    try:
        clock = " ".join(time_text.split()[:2])  # "09:49:42 AM" (drops the time-zone name)
        logged_in = datetime.strptime(f"{date_text} {clock}", "%Y-%m-%d %I:%M:%S %p")
    except ValueError:
        return ""
    best = None
    for when, student, floor in history:
        gap = abs((when - logged_in).total_seconds())
        if student == student_id and gap <= LEGACY_MATCH_SECONDS and (best is None or gap < best[0]):
            best = (gap, floor)
    return best[1] if best else ""


def _load_rows():
    """[(student, date, time, floor_key)], oldest first.

    Rows written before the Floor column existed get their floor from the check-in history."""
    if not LOG_FILE.exists():
        return []
    with LOG_FILE.open("r", newline="", encoding="utf-8-sig") as handle:
        raw = list(csv.DictReader(handle))
    history = None
    rows = []
    for r in raw:
        student = r.get("Student ID") or ""
        date_text = r.get("Login Date") or ""
        time_text = r.get("Login Time") or ""
        floor = (r.get("Floor") or "").strip()
        if not floor:
            if history is None:
                history = _checkin_history()
            floor = _guess_floor(student, date_text, time_text, history)
        rows.append((student, date_text, time_text, floor))
    return rows


def _add_floor_column():
    """One-time upgrade of a log written by an older version: add the Floor column."""
    with LOG_FILE.open("r", newline="", encoding="utf-8-sig") as handle:
        header = next(csv.reader(handle), [])
    if "Floor" in header:
        return
    rows = _load_rows()
    temp = LOG_FILE.with_name(LOG_FILE.name + ".tmp")
    try:
        with temp.open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.writer(handle)
            writer.writerow(FIELDS)
            writer.writerows(rows)
        os.replace(temp, LOG_FILE)
    except OSError:
        temp.unlink(missing_ok=True)
        raise


# ---------------------------------------------------------------------- public API
def record_student_login(student_id, floor=""):
    student_id = normalize_student_id(student_id)
    now = datetime.now().astimezone()
    header_needed = not LOG_FILE.exists() or LOG_FILE.stat().st_size == 0
    if not header_needed:
        _add_floor_column()
    with LOG_FILE.open("a", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        if header_needed:
            writer.writeheader()
        writer.writerow({
            "Student ID": student_id,
            "Login Date": now.strftime("%Y-%m-%d"),
            "Login Time": now.strftime("%I:%M:%S %p %Z"),
            "Floor": floor,
        })


def read_student_logins():
    """[(student, date, time)], newest first."""
    return [row[:3] for row in reversed(_load_rows())]


def read_student_logins_by_floor():
    """[(floor_key, (student, date, time))], newest first. Floor is "" when it can't be determined."""
    return [(row[3], row[:3]) for row in reversed(_load_rows())]
