"""Local activity logs used by staff tools."""
import csv, os, json
from datetime import datetime
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOGIN_FILE=os.path.join(ROOT,"data","student_login_log.csv")
EVENT_FILE=os.path.join(ROOT,"data","reservation_activity.json")
def record_student_login(student, floor):
    os.makedirs(os.path.dirname(LOGIN_FILE),exist_ok=True)
    new=not os.path.exists(LOGIN_FILE) or os.path.getsize(LOGIN_FILE)==0
    with open(LOGIN_FILE,"a",newline="",encoding="utf-8-sig") as f:
        w=csv.writer(f)
        if new: w.writerow(["Student Number","Date","Time","Floor"])
        now=datetime.now(); w.writerow([student,now.strftime("%Y-%m-%d"),now.strftime("%I:%M:%S %p"),floor])
def read_student_logins():
    if not os.path.exists(LOGIN_FILE): return []
    with open(LOGIN_FILE,newline="",encoding="utf-8-sig") as f: return list(reversed(list(csv.reader(f))))
def record_event(seat, action, student="", details=""):
    os.makedirs(os.path.dirname(EVENT_FILE),exist_ok=True)
    try:
        with open(EVENT_FILE,encoding="utf-8") as f: rows=json.load(f)
    except (OSError,ValueError): rows=[]
    rows.append({"time":datetime.now().strftime("%Y-%m-%d %I:%M:%S %p"),"seat":seat,"floor":seat.split("-",1)[0],"action":action,"student":student or "—","details":details})
    tmp=EVENT_FILE+".tmp"
    with open(tmp,"w",encoding="utf-8") as f: json.dump(rows,f,indent=2)
    os.replace(tmp,EVENT_FILE)
def read_events():
    try:
        with open(EVENT_FILE,encoding="utf-8") as f: return list(reversed(json.load(f)))
    except (OSError,ValueError): return []
